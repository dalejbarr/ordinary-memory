# eyeread
R library for reading in binary data files from eyetracking systems
(only works with EyeLink 1000 and 64-bit linux machines for the moment... sorry!)
